const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Database setup
const db = new sqlite3.Database('./expenses.db', (err) => {
    if (err) {
        console.error('Error membuka database:', err.message);
    } else {
        console.log('Terhubung ke database SQLite');
        initDatabase();
    }
});

// Inisialisasi tabel database
function initDatabase() {
    db.run(`
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) {
            console.error('Error membuat tabel:', err.message);
        } else {
            console.log('Tabel expenses siap digunakan');
        }
    });
}

// Routes

// Halaman utama
app.get('/', (req, res) => {
    const query = `
        SELECT * FROM expenses 
        ORDER BY date DESC, created_at DESC
    `;
    
    db.all(query, [], (err, expenses) => {
        if (err) {
            console.error('Error mengambil data:', err.message);
            return res.status(500).send('Error mengambil data');
        }
        
        // Hitung statistik
        const stats = calculateStats(expenses);
        
        res.render('index', { 
            expenses: expenses,
            stats: stats
        });
    });
});

// Tambah pengeluaran
app.post('/add-expense', (req, res) => {
    const { date, name, category, amount } = req.body;
    
    if (!date || !name || !category || !amount) {
        return res.status(400).json({ error: 'Semua field harus diisi' });
    }
    
    const query = `
        INSERT INTO expenses (date, name, category, amount)
        VALUES (?, ?, ?, ?)
    `;
    
    db.run(query, [date, name, category, parseFloat(amount)], function(err) {
        if (err) {
            console.error('Error menambah data:', err.message);
            return res.status(500).json({ error: 'Error menambah data' });
        }
        
        res.json({ 
            success: true, 
            message: 'Pengeluaran berhasil ditambahkan',
            id: this.lastID
        });
    });
});

// Hapus pengeluaran
app.delete('/delete-expense/:id', (req, res) => {
    const id = req.params.id;
    
    const query = 'DELETE FROM expenses WHERE id = ?';
    
    db.run(query, [id], function(err) {
        if (err) {
            console.error('Error menghapus data:', err.message);
            return res.status(500).json({ error: 'Error menghapus data' });
        }
        
        res.json({ 
            success: true, 
            message: 'Pengeluaran berhasil dihapus'
        });
    });
});

// API untuk statistik
app.get('/api/stats', (req, res) => {
    const query = 'SELECT * FROM expenses ORDER BY date DESC';
    
    db.all(query, [], (err, expenses) => {
        if (err) {
            console.error('Error mengambil data:', err.message);
            return res.status(500).json({ error: 'Error mengambil data' });
        }
        
        const stats = calculateStats(expenses);
        res.json(stats);
    });
});

// Fungsi untuk menghitung statistik
function calculateStats(expenses) {
    const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
    
    // Hitung per kategori
    const byCategory = {};
    expenses.forEach(exp => {
        if (!byCategory[exp.category]) {
            byCategory[exp.category] = 0;
        }
        byCategory[exp.category] += exp.amount;
    });
    
    // Cari kategori dengan pengeluaran terbesar
    let maxCategory = null;
    let maxAmount = 0;
    for (const [category, amount] of Object.entries(byCategory)) {
        if (amount > maxAmount) {
            maxAmount = amount;
            maxCategory = category;
        }
    }
    
    // Peringatan jika ada kategori > 40% dari total
    const warnings = [];
    for (const [category, amount] of Object.entries(byCategory)) {
        const percentage = (amount / total) * 100;
        if (percentage > 40) {
            warnings.push({
                category: category,
                amount: amount,
                percentage: percentage.toFixed(1)
            });
        }
    }
    
    return {
        total: total,
        count: expenses.length,
        byCategory: byCategory,
        maxCategory: maxCategory,
        maxAmount: maxAmount,
        warnings: warnings
    };
}

// Start server
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});

// Cleanup database saat aplikasi ditutup
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error('Error menutup database:', err.message);
        }
        console.log('Database ditutup');
        process.exit(0);
    });
});
